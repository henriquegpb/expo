/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 */

'use client';

import {
  Children,
  cloneElement,
  memo,
  useCallback,
  useMemo,
  useRef,
  useState,
  type ReactElement,
  type ReactNode
} from 'react';

import useMergeRefs from '../../modules/useMergeRefs';
import usePressEvents from '../../modules/usePressEvents';
import type { PressResponderConfig } from '../../modules/usePressEvents/PressResponder';
import type { ColorValue, Nullable, PlatformMethods } from '../../types';
import StyleSheet from '../StyleSheet';
import type { Props as TouchableWithoutFeedbackProps } from '../TouchableWithoutFeedback';
import View, { type ViewProps } from '../View';

type ViewStyle = ViewProps['style'];

type PressEvent = Parameters<
  NonNullable<PressResponderConfig['onPressStart']>
>[0];

type Props = Readonly<
  TouchableWithoutFeedbackProps & {
    activeOpacity?: Nullable<number>;
    onHideUnderlay?: Nullable<() => void>;
    onShowUnderlay?: Nullable<() => void>;
    style?: ViewStyle;
    testOnly_pressed?: Nullable<boolean>;
    underlayColor?: Nullable<ColorValue>;
  }
>;

type ExtraStyles = Readonly<{
  child: ViewStyle;
  underlay: ViewStyle;
}>;

function createExtraStyles(
  activeOpacity: Props['activeOpacity'],
  underlayColor: Props['underlayColor']
): ExtraStyles {
  return {
    child: { opacity: activeOpacity ?? 0.85 },
    underlay: {
      backgroundColor: underlayColor === undefined ? 'black' : underlayColor
    }
  };
}

function hasPressHandler(props: Props): boolean {
  return (
    props.onPress != null ||
    props.onPressIn != null ||
    props.onPressOut != null ||
    props.onLongPress != null
  );
}

/**
 * A wrapper for making views respond properly to touches.
 * On press down, the opacity of the wrapped view is decreased, which allows
 * the underlay color to show through, darkening or tinting the view.
 *
 * The underlay comes from wrapping the child in a new View, which can affect
 * layout, and sometimes cause unwanted visual artifacts if not used correctly,
 * for example if the backgroundColor of the wrapped view isn't explicitly set
 * to an opaque color.
 *
 * TouchableHighlight must have one child (not zero or more than one).
 * If you wish to have several child components, wrap them in a View.
 */
function TouchableHighlight(props: Props): ReactNode {
  const {
    activeOpacity,
    children,
    delayPressIn,
    delayPressOut,
    delayLongPress,
    disabled,
    focusable,
    onHideUnderlay,
    onLongPress,
    onPress,
    onPressIn,
    onPressOut,
    onShowUnderlay,
    ref,
    rejectResponderTermination,
    style,
    testOnly_pressed,
    underlayColor,
    ...rest
  } = props;

  const hostRef = useRef<(HTMLElement & PlatformMethods) | null>(null);
  const setRef = useMergeRefs(ref, hostRef);

  const [extraStyles, setExtraStyles] = useState<Nullable<ExtraStyles>>(
    testOnly_pressed === true
      ? createExtraStyles(activeOpacity, underlayColor)
      : null
  );

  const showUnderlay = useCallback(() => {
    if (!hasPressHandler(props)) {
      return;
    }
    setExtraStyles(createExtraStyles(activeOpacity, underlayColor));
    if (onShowUnderlay != null) {
      onShowUnderlay();
    }
  }, [activeOpacity, onShowUnderlay, props, underlayColor]);

  const hideUnderlay = useCallback(() => {
    if (testOnly_pressed === true) {
      return;
    }
    if (hasPressHandler(props)) {
      setExtraStyles(null);
      if (onHideUnderlay != null) {
        onHideUnderlay();
      }
    }
  }, [onHideUnderlay, props, testOnly_pressed]);

  const pressConfig = useMemo(
    () => ({
      cancelable: !rejectResponderTermination,
      disabled,
      delayLongPress,
      delayPressStart: delayPressIn,
      delayPressEnd: delayPressOut,
      onLongPress,
      onPress,
      onPressStart(event: PressEvent) {
        showUnderlay();
        if (onPressIn != null) {
          onPressIn(event);
        }
      },
      onPressEnd(event: PressEvent) {
        hideUnderlay();
        if (onPressOut != null) {
          onPressOut(event);
        }
      }
    }),
    [
      delayLongPress,
      delayPressIn,
      delayPressOut,
      disabled,
      onLongPress,
      onPress,
      onPressIn,
      onPressOut,
      rejectResponderTermination,
      showUnderlay,
      hideUnderlay
    ]
  );

  const pressEventHandlers = usePressEvents(pressConfig);

  const child = Children.only(children) as ReactElement<{
    style?: ViewStyle;
    [key: string]: unknown;
  }>;

  return (
    <View
      {...rest}
      {...(pressEventHandlers as unknown as Partial<ViewProps>)}
      accessibilityDisabled={disabled}
      focusable={!disabled && focusable !== false}
      pointerEvents={disabled ? 'box-none' : undefined}
      ref={setRef}
      style={[
        styles.root,
        style,
        !disabled && styles.actionable,
        extraStyles && extraStyles.underlay
      ]}
    >
      {cloneElement(child, {
        style: [child.props.style, extraStyles && extraStyles.child]
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    userSelect: 'none'
  },
  actionable: {
    cursor: 'pointer',
    touchAction: 'manipulation'
  }
});

const MemoedTouchableHighlight = memo(TouchableHighlight);
MemoedTouchableHighlight.displayName = 'TouchableHighlight';

export default MemoedTouchableHighlight;
